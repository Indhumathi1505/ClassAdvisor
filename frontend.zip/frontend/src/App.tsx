
import React, { useState, useEffect } from 'react';
import { UserRole, AppState, Student, Subject, MarkRecord, AttendanceRecord } from './types';
import Login from './components/Login';
import AdvisorDashboard from './components/AdvisorDashboard';
import StaffDashboard from './components/StaffDashboard';
import StudentDashboard from './components/StudentDashboard';
import { LogOut, GraduationCap, LayoutDashboard } from 'lucide-react';

import { api } from './api.ts';

import BackgroundParticles from './components/BackgroundParticles';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<{ role: UserRole; identifier: string; data?: any } | null>(null);
  const [state, setState] = useState<AppState>({
    students: [],
    subjects: [],
    marks: [],
    labMarks: [],
    attendance: [],
    masterAttendance: [],
    semesterGrades: [],
    config: {
      years: 4,
      semesters: 8,
      internalsPerSem: 2
    }
  });

  useEffect(() => {
    api.getState()
      .then(data => setState(data))
      .catch(err => console.error("Failed to load state from backend", err));
  }, []);

  const handleLogout = () => {
    setCurrentUser(null);
  };

  const updateState = (newState: Partial<AppState>) => {
    setState(prev => ({ ...prev, ...newState }));
  };

  const renderContent = () => {
    if (!currentUser) {
      return <Login state={state} onLogin={setCurrentUser} />;
    }

    switch (currentUser.role) {
      case UserRole.ADVISOR:
        return <AdvisorDashboard state={state} updateState={updateState} onLogout={handleLogout} />;
      case UserRole.STAFF:
        return <StaffDashboard state={state} updateState={updateState} staffName={currentUser.identifier} loginSubject={currentUser.data} onLogout={handleLogout} />;
      case UserRole.STUDENT:
        return <StudentDashboard state={state} studentRegNo={currentUser.identifier} onLogout={handleLogout} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col relative text-gray-800">
      <BackgroundParticles />
      <nav className="bg-brand-primary/95 backdrop-blur-sm text-white px-6 py-4 flex justify-between items-center shadow-lg sticky top-0 z-50 border-b border-brand-secondary/50">
        <div className="flex items-center gap-3 group cursor-pointer">
          <div className="p-2 bg-white/10 group-hover:bg-white/20 rounded-lg transition-all duration-300">
            <GraduationCap className="w-6 h-6 text-white group-hover:text-cyan-200" />
          </div>
          <h1 className="text-xl font-extrabold tracking-tight text-white group-hover:text-cyan-200 transition-colors drop-shadow-sm">
            Class Advisor <span className="text-cyan-400 group-hover:text-white transition-colors">Pro</span>
          </h1>
        </div>

        {currentUser && (
          <div className="flex items-center gap-4">
            <div className="text-sm">
              <span className="opacity-70">Logged in as:</span>
              <span className="ml-1 font-semibold">{currentUser.identifier} ({currentUser.role})</span>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-3 py-1.5 bg-red-500 hover:bg-red-600 rounded-md transition-colors text-sm font-medium"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        )}
      </nav>

      <main className="flex-grow container mx-auto p-4 md:p-8 relative z-10">
        {renderContent()}
      </main>

      <footer className="bg-white/80 backdrop-blur-md border-t py-4 text-center text-gray-500 text-sm relative z-10">
        &copy; {new Date().getFullYear()} Class Advisor Management System. Designed for Excellence.
      </footer>
    </div>
  );
};

export default App;
